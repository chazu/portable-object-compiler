
/* dummy def for compilers that require struct def */
struct modDescriptor { int dummy; };

extern struct modDescriptor *_OBJCBIND_scalar();
extern struct modDescriptor *_OBJCBIND_pointer();
extern struct modDescriptor *_OBJCBIND_compdef();
extern struct modDescriptor *_OBJCBIND_exprstmt();
extern struct modDescriptor *_OBJCBIND_dfltstmt();
extern struct modDescriptor *_OBJCBIND_OutOfMem();
extern struct modDescriptor *_OBJCBIND_lex();
extern struct modDescriptor *_OBJCBIND_namedecl();
extern struct modDescriptor *_OBJCBIND_Exceptn();
extern struct modDescriptor *_OBJCBIND_Message();
extern struct modDescriptor *_OBJCBIND_structsp();
extern struct modDescriptor *_OBJCBIND_trlunit();
extern struct modDescriptor *_OBJCBIND_gasmstmt();
extern struct modDescriptor *_OBJCBIND_typeof();
extern struct modDescriptor *_OBJCBIND_contstmt();
extern struct modDescriptor *_OBJCBIND_setseq();
extern struct modDescriptor *_OBJCBIND_method();
extern struct modDescriptor *_OBJCBIND_lexfiltr();
extern struct modDescriptor *_OBJCBIND_enumtor();
extern struct modDescriptor *_OBJCBIND_keyseq();
extern struct modDescriptor *_OBJCBIND_sizeof();
extern struct modDescriptor *_OBJCBIND_lblstmt();
extern struct modDescriptor *_OBJCBIND_arydecl();
extern struct modDescriptor *_OBJCBIND_dotxpr();
extern struct modDescriptor *_OBJCBIND_set();
extern struct modDescriptor *_OBJCBIND_stclass();
extern struct modDescriptor *_OBJCBIND_assoc();
extern struct modDescriptor *_OBJCBIND_pfixxpr();
extern struct modDescriptor *_OBJCBIND_casestmt();
extern struct modDescriptor *_OBJCBIND_constxpr();
extern struct modDescriptor *_OBJCBIND_condxpr();
extern struct modDescriptor *_OBJCBIND_idarray();
extern struct modDescriptor *_OBJCBIND_unknownt();
extern struct modDescriptor *_OBJCBIND_precdecl();
extern struct modDescriptor *_OBJCBIND_yacc();
extern struct modDescriptor *_OBJCBIND_ordcltn();
extern struct modDescriptor *_OBJCBIND_identxpr();
extern struct modDescriptor *_OBJCBIND_assign();
extern struct modDescriptor *_OBJCBIND_precxpr();
extern struct modDescriptor *_OBJCBIND_Object();
extern struct modDescriptor *_OBJCBIND_outofbnd();
extern struct modDescriptor *_OBJCBIND_classdef();
extern struct modDescriptor *_OBJCBIND_globdef();
extern struct modDescriptor *_OBJCBIND_initdecl();
extern struct modDescriptor *_OBJCBIND_dictnary();
extern struct modDescriptor *_OBJCBIND_selector();
extern struct modDescriptor *_OBJCBIND_fundef();
extern struct modDescriptor *_OBJCBIND_options();
extern struct modDescriptor *_OBJCBIND_funcall();
extern struct modDescriptor *_OBJCBIND_expr();
extern struct modDescriptor *_OBJCBIND_aryvar();
extern struct modDescriptor *_OBJCBIND_stkframe();
extern struct modDescriptor *_OBJCBIND_keywxpr();
extern struct modDescriptor *_OBJCBIND_node();
extern struct modDescriptor *_OBJCBIND_valueseq();
extern struct modDescriptor *_OBJCBIND_btincall();
extern struct modDescriptor *_OBJCBIND_notfound();
extern struct modDescriptor *_OBJCBIND_Block();
extern struct modDescriptor *_OBJCBIND_ifstmt();
extern struct modDescriptor *_OBJCBIND_unyxpr();
extern struct modDescriptor *_OBJCBIND_parmdef();
extern struct modDescriptor *_OBJCBIND_util();
extern struct modDescriptor *_OBJCBIND_cltnseq();
extern struct modDescriptor *_OBJCBIND_array();
extern struct modDescriptor *_OBJCBIND_forstmt();
extern struct modDescriptor *_OBJCBIND_deref();
extern struct modDescriptor *_OBJCBIND_binxpr();
extern struct modDescriptor *_OBJCBIND_var();
extern struct modDescriptor *_OBJCBIND_objcrt();
extern struct modDescriptor *_OBJCBIND_ocstring();
extern struct modDescriptor *_OBJCBIND_treeseq();
extern struct modDescriptor *_OBJCBIND_datadef();
extern struct modDescriptor *_OBJCBIND_sortcltn();
extern struct modDescriptor *_OBJCBIND_gasmop();
extern struct modDescriptor *_OBJCBIND_dasmstmt();
extern struct modDescriptor *_OBJCBIND_dostmt();
extern struct modDescriptor *_OBJCBIND_gattrib();
extern struct modDescriptor *_OBJCBIND_arrowxpr();
extern struct modDescriptor *_OBJCBIND_cppdirec();
extern struct modDescriptor *_OBJCBIND_keywdecl();
extern struct modDescriptor *_OBJCBIND_ascfiler();
extern struct modDescriptor *_OBJCBIND_relxpr();
extern struct modDescriptor *_OBJCBIND_gatrdecl();
extern struct modDescriptor *_OBJCBIND_objc1();
extern struct modDescriptor *_OBJCBIND_switstmt();
extern struct modDescriptor *_OBJCBIND_funbody();
extern struct modDescriptor *_OBJCBIND_rtrnstmt();
extern struct modDescriptor *_OBJCBIND_listxpr();
extern struct modDescriptor *_OBJCBIND_whilstmt();
extern struct modDescriptor *_OBJCBIND_type();
extern struct modDescriptor *_OBJCBIND_fundecl();
extern struct modDescriptor *_OBJCBIND_def();
extern struct modDescriptor *_OBJCBIND_badvers();
extern struct modDescriptor *_OBJCBIND_parmlist();
extern struct modDescriptor *_OBJCBIND_commaxpr();
extern struct modDescriptor *_OBJCBIND_stardecl();
extern struct modDescriptor *_OBJCBIND_gotostmt();
extern struct modDescriptor *_OBJCBIND_typeinc();
extern struct modDescriptor *_OBJCBIND_indexxpr();
extern struct modDescriptor *_OBJCBIND_addrof();
extern struct modDescriptor *_OBJCBIND_selxpr();
extern struct modDescriptor *_OBJCBIND_sequence();
extern struct modDescriptor *_OBJCBIND_stmt();
extern struct modDescriptor *_OBJCBIND_msgxpr();
extern struct modDescriptor *_OBJCBIND_methdef();
extern struct modDescriptor *_OBJCBIND_compstmt();
extern struct modDescriptor *_OBJCBIND_decl();
extern struct modDescriptor *_OBJCBIND_symbol();
extern struct modDescriptor *_OBJCBIND_blockxpr();
extern struct modDescriptor *_OBJCBIND_enumsp();
extern struct modDescriptor *_OBJCBIND_bflddecl();
extern struct modDescriptor *_OBJCBIND_castxpr();
extern struct modDescriptor *_OBJCBIND_cltn();
extern struct modDescriptor *_OBJCBIND_pfixdecl();

/* this must match objcrt.m datatype */
static struct modEntry {
	struct modDescriptor *(*modLink)();
	struct modDescriptor *modInfo;
} _msgControl[] = {
	{_OBJCBIND_scalar,0},
	{_OBJCBIND_pointer,0},
	{_OBJCBIND_compdef,0},
	{_OBJCBIND_exprstmt,0},
	{_OBJCBIND_dfltstmt,0},
	{_OBJCBIND_OutOfMem,0},
	{_OBJCBIND_lex,0},
	{_OBJCBIND_namedecl,0},
	{_OBJCBIND_Exceptn,0},
	{_OBJCBIND_Message,0},
	{_OBJCBIND_structsp,0},
	{_OBJCBIND_trlunit,0},
	{_OBJCBIND_gasmstmt,0},
	{_OBJCBIND_typeof,0},
	{_OBJCBIND_contstmt,0},
	{_OBJCBIND_setseq,0},
	{_OBJCBIND_method,0},
	{_OBJCBIND_lexfiltr,0},
	{_OBJCBIND_enumtor,0},
	{_OBJCBIND_keyseq,0},
	{_OBJCBIND_sizeof,0},
	{_OBJCBIND_lblstmt,0},
	{_OBJCBIND_arydecl,0},
	{_OBJCBIND_dotxpr,0},
	{_OBJCBIND_set,0},
	{_OBJCBIND_stclass,0},
	{_OBJCBIND_assoc,0},
	{_OBJCBIND_pfixxpr,0},
	{_OBJCBIND_casestmt,0},
	{_OBJCBIND_constxpr,0},
	{_OBJCBIND_condxpr,0},
	{_OBJCBIND_idarray,0},
	{_OBJCBIND_unknownt,0},
	{_OBJCBIND_precdecl,0},
	{_OBJCBIND_yacc,0},
	{_OBJCBIND_ordcltn,0},
	{_OBJCBIND_identxpr,0},
	{_OBJCBIND_assign,0},
	{_OBJCBIND_precxpr,0},
	{_OBJCBIND_Object,0},
	{_OBJCBIND_outofbnd,0},
	{_OBJCBIND_classdef,0},
	{_OBJCBIND_globdef,0},
	{_OBJCBIND_initdecl,0},
	{_OBJCBIND_dictnary,0},
	{_OBJCBIND_selector,0},
	{_OBJCBIND_fundef,0},
	{_OBJCBIND_options,0},
	{_OBJCBIND_funcall,0},
	{_OBJCBIND_expr,0},
	{_OBJCBIND_aryvar,0},
	{_OBJCBIND_stkframe,0},
	{_OBJCBIND_keywxpr,0},
	{_OBJCBIND_node,0},
	{_OBJCBIND_valueseq,0},
	{_OBJCBIND_btincall,0},
	{_OBJCBIND_notfound,0},
	{_OBJCBIND_Block,0},
	{_OBJCBIND_ifstmt,0},
	{_OBJCBIND_unyxpr,0},
	{_OBJCBIND_parmdef,0},
	{_OBJCBIND_util,0},
	{_OBJCBIND_cltnseq,0},
	{_OBJCBIND_array,0},
	{_OBJCBIND_forstmt,0},
	{_OBJCBIND_deref,0},
	{_OBJCBIND_binxpr,0},
	{_OBJCBIND_var,0},
	{_OBJCBIND_objcrt,0},
	{_OBJCBIND_ocstring,0},
	{_OBJCBIND_treeseq,0},
	{_OBJCBIND_datadef,0},
	{_OBJCBIND_sortcltn,0},
	{_OBJCBIND_gasmop,0},
	{_OBJCBIND_dasmstmt,0},
	{_OBJCBIND_dostmt,0},
	{_OBJCBIND_gattrib,0},
	{_OBJCBIND_arrowxpr,0},
	{_OBJCBIND_cppdirec,0},
	{_OBJCBIND_keywdecl,0},
	{_OBJCBIND_ascfiler,0},
	{_OBJCBIND_relxpr,0},
	{_OBJCBIND_gatrdecl,0},
	{_OBJCBIND_objc1,0},
	{_OBJCBIND_switstmt,0},
	{_OBJCBIND_funbody,0},
	{_OBJCBIND_rtrnstmt,0},
	{_OBJCBIND_listxpr,0},
	{_OBJCBIND_whilstmt,0},
	{_OBJCBIND_type,0},
	{_OBJCBIND_fundecl,0},
	{_OBJCBIND_def,0},
	{_OBJCBIND_badvers,0},
	{_OBJCBIND_parmlist,0},
	{_OBJCBIND_commaxpr,0},
	{_OBJCBIND_stardecl,0},
	{_OBJCBIND_gotostmt,0},
	{_OBJCBIND_typeinc,0},
	{_OBJCBIND_indexxpr,0},
	{_OBJCBIND_addrof,0},
	{_OBJCBIND_selxpr,0},
	{_OBJCBIND_sequence,0},
	{_OBJCBIND_stmt,0},
	{_OBJCBIND_msgxpr,0},
	{_OBJCBIND_methdef,0},
	{_OBJCBIND_compstmt,0},
	{_OBJCBIND_decl,0},
	{_OBJCBIND_symbol,0},
	{_OBJCBIND_blockxpr,0},
	{_OBJCBIND_enumsp,0},
	{_OBJCBIND_bflddecl,0},
	{_OBJCBIND_castxpr,0},
	{_OBJCBIND_cltn,0},
	{_OBJCBIND_pfixdecl,0},
	{0,0}
};

/* non-NULL _objcModules disables auto-init */
struct modEntry *_objcModules = _msgControl;

